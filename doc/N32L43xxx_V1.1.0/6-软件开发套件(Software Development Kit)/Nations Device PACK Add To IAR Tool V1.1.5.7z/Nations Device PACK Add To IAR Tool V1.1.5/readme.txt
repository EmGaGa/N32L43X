﻿/* Nations Device PACK Add To IAR Tool
   使用说明和版本更新记录
 */
 
/* 1.使用说明 */
/*   i.  以管理员权限运行“Nations Device PACK Add To IAR Tool Vx.x.x.exe”
     ii. IAR安转目录选择，例如C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.5
     iii.点击“安装”	
*/

/* 2.版本更新记录 */
/*   
     V1.0.0 初始版本

     V1.1.0 安装时添加删除原有PACK包的弹窗选择

     V1.1.1 更新已知BUG

     V1.1.2 更新已知BUG
     
     V1.1.3 追加N32G435G8Q7型号
     
     V1.1.4 优化FLASH下载算法
	 
	 V1.1.5 增加N32G435GBQ7
*/