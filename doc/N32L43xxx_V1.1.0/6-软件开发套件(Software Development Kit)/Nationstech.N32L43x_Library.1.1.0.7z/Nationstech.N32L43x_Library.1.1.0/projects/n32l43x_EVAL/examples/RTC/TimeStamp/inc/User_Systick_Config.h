#ifndef __USER_SYSTICK_CONFIG_H__
#define __USER_SYSTICK_CONFIG_H__

extern uint32_t DBG_SysTick_Config(uint32_t ticks);
extern void SysTick_Delay_Ms(__IO uint32_t ms);

#endif/*__USER_SYSTICK_CONFIG_H__*/
