1、功能说明
 
	1、  USB Printer 打印机
 
2、使用环境
 
	/* 硬件环境：工程对应的开发硬件平台 */
	开发板：N32L43XM-STB N32L40XM-STB V1.1
 
3、使用说明

	/* 描述相关模块配置方法；例如:时钟，I/O等 */
	1、SystemClock：108MHz
	2、USBClock: 48MHz
				  
	/* 描述Demo的测试步骤和现象 */
	1.编译后下载程序复位运行；
	2.通过 USB 线连接 J3 USB 口，电脑识别出 USB 打印支持；
 
4、注意事项
	无